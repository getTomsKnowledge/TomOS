from __future__ import annotations
import asyncio
from typing import Any, Dict, List, Optional
from contextlib import AsyncExitStack

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()  # load environment variables from .env

class MCPClient:
    def __init__(self):
        # Initialize session and client objects
        self.session: Optional[ClientSession] = None
        self.exit_stack = AsyncExitStack()
        self.openai = OpenAI()
        self.model = "gpt-4o-mini"  # Default model; change as needed
        self.stdio = None
        self.write = None
        # Additional attributes for managing state can be added here
    # methods will go here


    async def connect_to_server(self, server_script_path: str):
        """Connect to an MCP server

        Args:
            server_script_path: Path to the server script (.py or .js)
        """
        is_python = server_script_path.endswith('.py')
        is_js = server_script_path.endswith('.js')
        if not (is_python or is_js):
            raise ValueError("Server script must be a .py or .js file")

        command = "python" if is_python else "node"
        server_params = StdioServerParameters(
            command=command,
            args=[server_script_path],
            env=None
        )

        stdio_transport = await self.exit_stack.enter_async_context(stdio_client(server_params))
        self.stdio, self.write = stdio_transport
        self.session = await self.exit_stack.enter_async_context(ClientSession(self.stdio, self.write))

        await self.session.initialize()

        # List available tools
        response = await self.session.list_tools()
        tools = response.tools
        print("\nConnected to server with tools:", [tool.name for tool in tools])

    async def process_query(self, query: str) -> str:
        """Process a query using ChatGPT and available tools"""
        if self.session is None:
            raise RuntimeError("Not connected to an MCP server")

        # 1) Discover MCP tools and convert to OpenAI tool schemas
        response = await self.session.list_tools()
        available_tools = [{
            "type": "function",
            "function": {
                "name": tool.name,
                "description": tool.description or "",
                "parameters": tool.inputSchema or {"type": "object", "properties": {}}
            }
        } for tool in response.tools]

        # 2) Build a Messages-style input for OpenAI
        # (You can also pass a plain string; messages are nicer for multi-turn with tools
        messages: List[Dict[str, Any]] = [
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": query}
                ]
            }
        ]
        # Process response and handle tool calls
        final_text_chunks: List[str] = []

        # 3) Call OpenAI onnce, then loop on tool calls until done
        while True:
            # NOTE: Responses API is sync; call from async code is fine here (blocking).
            # If you want non-blocking, wrap in asyncio.to_thread(...)

            response = self.openai.responses.create(
                model=self.model,
                input=messages,
                tools=available_tools,
                max_output_tokens=1000,   # analogous to max_tokens
            )

            # The Responses API can return:
            #  - direct text segments in response.output
            #  - tool call directives when the model wants to use a tool
            # We’ll collect text and detect any tool call.
            tool_call = None

            # Aggregate any assistant text emitted alongside tool calls
            # (The SDK exposes a consolidated .output list and .output_text helper.)
            if getattr(response, "output_text", None):
                final_text_chunks.append(response.output_text)

            # Inspect structured output segments for tool calls
            # (Each segment in response.output can be text or a tool call request)
            for seg in getattr(response, "output", []) or []:
                if getattr(seg, "type", None) in ("tool_call", "function_call", "tool_use"):
                    tool_call = seg
                    break

            # If no tool call requested, we're done; return the accumulated text
            if tool_call is None:
                print("\n".join(chunk for chunk in final_text_chunks if chunk))
                break

            # 4) Execute MCP tool call
            # The segment typically includes tool name and JSON arguments
            tool_name = getattr(tool_call, "name", None) or getattr(tool_call, "call", {}).get("name")
            tool_args = getattr(tool_call, "arguments", None) or getattr(tool_call, "call", {}).get("arguments")
            if tool_args is None:
                tool_args = {}

            # Call the MCP tool asynchronously
            tool_result = await self.session.call_tool(tool_name, tool_args)

            # 5) Append an assistant tool-call turn + a user tool-result turn
            #    to messages, then loop again to let the model finish the thought.
            #
            # NB: In the Responses API, we keep the conversation in "messages" form.
            # We represent the assistant's tool call and our returned tool result explicitly.
            messages.append({
                "role": "assistant",
                "content": [
                    # Echo any assistant text already emitted (optional but keeps parity)
                    *([{"type": "output_text", "text": response.output_text}] if getattr(response, "output_text", None) else []),
                    {
                        "type": "tool_call",
                        "name": tool_name,
                        "arguments": tool_args,
                    },
                ],
            })

            # The tool_result payload should be textual or structured; MCP often returns
            # a list of content parts. We pass it back as a user turn with a tool_result.
            messages.append({
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "name": tool_name,
                        # Prefer structured content if present; else fallback to text
                        "content": getattr(tool_result, "structured_content", None) or getattr(tool_result, "content", None) or str(tool_result),
                    }
                ],
            })
        return "\n".join(final_text_chunks)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python mcp_openai_client.py \"what's the forecast for 37.77,-122.42?\"")
        sys.exit(1)
    print(asyncio.run(run_standalone(sys.argv[1])))