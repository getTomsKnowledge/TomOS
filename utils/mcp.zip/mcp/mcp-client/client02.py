from __future__ import annotations

from contextlib import AsyncExitStack
import asyncio, os, sys, json
from typing import Any, Dict, List, Optional

from openai import OpenAI
from dotenv import load_dotenv

# MCP Python SDK (client + stdio transport helpers)
from mcp.client.stdio import StdioServerParameters, stdio_client
from mcp.client.session import ClientSession


# --- Config: point this to your National Weather Service (NWS) MCP server entrypoint (script or exe) ---
NWS_SERVER_CMD = ["python", "-m", "weather.py"]  # e.g., ["python", "weather_server.py"]
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")


def to_openai_tool_schemas(tools) -> List[Dict[str, Any]]:
    """Convert MCP tool descriptors to OpenAI tool/function schemas."""
    out: List[Dict[str, Any]] = []
    for t in tools:
        out.append({
            "type": "function",
            "function": {
                "name": t.name,
                "description": t.description or "",
                "parameters": t.inputSchema or {"type": "object", "properties": {}},
            }
        })
    return out


async def run_standalone(query: str) -> str:
    # 0) Decide interpreter for your server script
    command = "python" if server_script_path.endswith(".py") else "node"
    server_params = StdioServerParameters(
        command=command,
        args=[server_script_path],
        env=None,
    )

    exit_stack = AsyncExitStack()
    await exit_stack.__aenter__()
    try:
        # 1) Open stdio transport and get (read_stream, write_stream)
        read_stream, write_stream = await exit_stack.enter_async_context(
            stdio_client(server_params)
        )

        # 2) Create ClientSession with those streams and initialize it
        session = await exit_stack.enter_async_context(
            ClientSession(read_stream, write_stream)
        )
        await session.initialize()

        # 3) (now safe to use) e.g., list tools
        tools_resp = await session.list_tools()
        load_dotenv()
        client = OpenAI()  # OPENAI_API_KEY pulled from env

        # 4) Connect to NWS MCP server over stdio (recommended by spec)
        #    (If your server is already running another way, adjust to its transport.)
        params = StdioServerParameters(command=NWS_SERVER_CMD[0], args=NWS_SERVER_CMD[1:])
        async with ClientSession(params) as session:
            # 2) Discover tools
            capabilities = await session.list_tools()
            available_tools = to_openai_tool_schemas(capabilities.tools)

            # Prepare a messages-style transcript for OpenAI Responses
            messages: List[Dict[str, Any]] = [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_text",
                            "text": query
                            }
                    ]
                }
            ]

            final_text_chunks: List[str] = []
            max_tool_steps = 8  # guard against infinite loops

            for _ in range(max_tool_steps):
                # 3) Ask OpenAI with tools advertised by MCP server
                resp = client.responses.create(
                    model=OPENAI_MODEL,
                    input=messages,
                    tools=available_tools,
                    max_output_tokens=800,
                )

                # Collect any assistant free text
                if getattr(resp, "output_text", None):
                    final_text_chunks.append(resp.output_text)

                # Look for a tool call in structured segments
                tool_call = None
                for seg in getattr(resp, "output", []) or []:
                    if getattr(seg, "type", None) in ("tool_call", "function_call", "tool_use"):
                        tool_call = seg
                        break

                # No tool call requested → we are done; break to final return
                if tool_call is None:
                    break

                # 4) Execute the requested MCP tool
                name = getattr(tool_call, "name", None) or getattr(getattr(tool_call, "call", None), "name", None)
                args = getattr(tool_call, "arguments", None) or getattr(getattr(tool_call, "call", None), "arguments", None) or {}
                try:
                    tool_result = await session.call_tool(name, args)
                except Exception as e:
                    # Normalize transport/tool error back to the model
                    tool_result_payload = {"error": str(e)}
                else:
                    # Prefer structured content if your MCP server returns it
                    tool_result_payload = (
                        getattr(tool_result, "structured_content", None)
                        or getattr(tool_result, "content", None)
                        or tool_result
                    )

                # 5) Append assistant tool_call + user tool_result turns, then loop
                assistant_turn: Dict[str, Any] = {"role": "assistant", "content": []}
                if getattr(resp, "output_text", None):
                    assistant_turn["content"].append({"type": "output_text", "text": resp.output_text})
                assistant_turn["content"].append({
                    "type": "tool_call",
                    "name": name,
                    "arguments": args,
                })
                messages.append(assistant_turn)

                messages.append({
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "name": name,
                            # Pass through JSON-able payload; stringify if necessary
                            "content": tool_result_payload if isinstance(tool_result_payload, (dict, list, str))
                                    else json.dumps(tool_result_payload, default=str)
                        }
                    ]
                })

            # 6) Return is OUTSIDE the loop (mechanics match your Anthropic intent)
            return "\n".join(chunk for chunk in final_text_chunks if chunk)
    finally:
        await exit_stack.aclose()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python client.py \"what's the forecast for 37.77,-122.42?\"")
        sys.exit(1)
    print(asyncio.run(run_standalone(sys.argv[1])))