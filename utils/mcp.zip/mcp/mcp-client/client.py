# client.py (drop-in)
from __future__ import annotations

import argparse, asyncio, json, os, sys
from contextlib import AsyncExitStack
from typing import Any, Dict, List

from dotenv import load_dotenv
from openai import OpenAI

from mcp.client.stdio import StdioServerParameters, stdio_client
from mcp.client.session import ClientSession

# Debugging:
import logging

logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)
#logger.debug("This is a debug message: var=%r", my_var)
#logger.info("Starting process %s", process_name)
#logger.error("An error occurred: %s", err)



def _normalize_schema(sch: Any) -> Dict[str, Any]:
    if not isinstance(sch, dict):
        return {"type": "object", "properties": {}}
    if sch.get("type") != "object":
        # Responses tool params must be a JSON Object schema
        sch = {"type": "object", "properties": sch.get("properties", {})}
    sch.setdefault("properties", {})
    return sch

def _to_openai_tool_schemas(mcp_tools) -> List[Dict[str, Any]]:
    tools: List[Dict[str, Any]] = []
    for t in mcp_tools:
        params = _normalize_schema(getattr(t, "inputSchema", None))
        # NOTE: name at TOP LEVEL (fix for “Missing required parameter: tools[0].name”)
        tools.append({
            "type": "function",
            "name": t.name,
            "description": (getattr(t, "description", "") or "")[:512],
            "parameters": params,
        })
    return tools

def sanitize_messages_for_api(msgs: list[dict]) -> list[dict]:
    """Deep clone and force convert any non-primitive content to JSON-safe."""
    import copy
    out = copy.deepcopy(msgs)
    def _clean(obj):
        # If it’s a custom object with .text, convert
        if hasattr(obj, "text"):
            return obj.text
        # If it’s a mapping
        if isinstance(obj, dict):
            return {k: _clean(v) for k, v in obj.items()}
        # If it’s a list/tuple
        if isinstance(obj, (list, tuple)):
            return [_clean(v) for v in obj]
        # Primitive
        if obj is None or isinstance(obj, (str, int, float, bool)):
            return obj
        # Fallback: to str
        return str(obj)
    for msg in out:
        if "content" in msg:
            msg["content"] = _clean(msg["content"])
    return out

def to_primitive(obj):
    if hasattr(obj, "text"):           # unwrap SDK TextContent
        return obj.text
    if isinstance(obj, dict):
        return {k: to_primitive(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_primitive(v) for v in obj]
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    return str(obj)

async def handle_tool_turn(resp, messages, session, last_call_id, last_call_args):
    """
    Given the current resp and message history, decide whether to:
    - exit (no tool call)
    - execute the tool
    - append the appropriate assistant/tool messages
    Returns:
        tuple: (should_continue: bool, new_last_call_id, new_last_call_args)
    """
    # Step 1: detect tool_call in this resp
    tool_call = None
    for seg in (getattr(resp, "output", []) or []):
        if getattr(seg, "type", None) in ("tool_call", "function_call", "tool_use"):
            tool_call = seg
            break

    if tool_call is None:
        return False, last_call_id, last_call_args

    call_id = getattr(tool_call, "id", None) or getattr(getattr(tool_call, "call", None), "id", None)
    raw = getattr(tool_call, "arguments", None) or getattr(getattr(tool_call, "call", None), "arguments", None)

    # Exit if no arguments
    if not raw:
        return False, last_call_id, last_call_args

    # Exit if repeating
    if call_id == last_call_id and raw == last_call_args:
        return False, last_call_id, last_call_args

    # Parse arguments
    if isinstance(raw, str):
        try:
            tool_args = json.loads(raw)
        except json.JSONDecodeError:
            tool_args = {}
    else:
        tool_args = raw or {}

    # Call the tool
    try:
        tool_result = await session.call_tool(getattr(tool_call, "name", None), tool_args)
        payload = (
            getattr(tool_result, "structured_content", None)
            or getattr(tool_result, "content", None)
            or tool_result
        )
    except Exception as e:
        payload = {"error": str(e)}

    # Normalize result_content
    if hasattr(payload, "text"):
        result_content = payload.text
    elif isinstance(payload, (dict, list, str)):
        result_content = payload
    else:
        result_content = json.dumps(payload, default=str)

    # Append the assistant’s tool call and the tool result (top-level)
    messages.append({
        "tool_calls": [
            {
                "id": call_id,
                "type": "function",
                "function": {
                    "name": getattr(tool_call, "name", None),
                    "arguments": to_primitive(tool_args)
                }
            }
        ]
    })
    messages.append({
        "role": "tool",
        "tool_call_id": call_id,
        "name": getattr(tool_call, "name", None),
        "content": result_content
    })
    
    logger.debug(f'Appended tool result for {getattr(tool_call, "name", None)}: {result_content}\n')

    return True, call_id, raw, tool_call, result_content

async def run(query: str, server_path: str, model: str = "gpt-4o-mini") -> str:
    #logger.debug("This is a debug message: var=%r", my_var)
    #logger.info("Starting process %s", process_name)
    #logger.error("An error occurred: %s", err)

    logger.debug("Running MCP client with query: %s\n", query)

    load_dotenv()
    client = OpenAI()

    logger.debug(f'Base URL is: {client.websocket_base_url}\n')

    server_abspath = os.path.abspath(server_path)
    server_dir = os.path.dirname(server_abspath)

    logger.debug(f'Server directory: {server_dir}\n')


    server_params = StdioServerParameters(
        command=sys.executable,
        args=[server_abspath],
        cwd=server_dir,
        env={"PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8"},
        encoding="utf-8",
        encoding_error_handler="strict",
    )

    logger.debug(f'Starting MCP server with command: {server_params.command} {server_params.args}\nCommands include: {sys.executable}\n\n')

    async with AsyncExitStack() as stack:
        read_stream, write_stream = await stack.enter_async_context(stdio_client(server_params))
        session = await stack.enter_async_context(ClientSession(read_stream, write_stream))
        logger.debug('Stdio server connection established.\n')
        await session.initialize()
        logger.debug('Stdio server handshake complete.\n')

        tools_resp = await session.list_tools()
        available_tools = _to_openai_tool_schemas(tools_resp.tools)
        if not available_tools:
            raise RuntimeError("MCP server exposed no tools.")
        else:
            logger.debug(f'Available tools: {[t["name"] for t in available_tools]}\n')
            logger.debug(f'Using OpenAI model: {model}\n')
        messages: List[Dict[str, Any]] = [
            {"role": "user", "content": [{"type": "input_text", "text": query}]}
        ]

        final_text_chunks: List[str] = []
        last_call_id = None
        last_call_args = None
        max_steps = 8  # guard against infinite loops

        for _step in range(max_steps):

            sanitized = sanitize_messages_for_api(messages)
            
            if _step == 0:
                resp = client.responses.create(
                    model=model,
                    input=sanitized,
                    tools=available_tools,
                    max_output_tokens=800,
                )
            else:
                break
                """
                Bug prevents multiple calls; workaround is to re-call with full history each time.
                See:    
                resp = client.responses.create(
                    model=model,
                    input=sanitized,
                    tools=available_tools,
                    max_output_tokens=800
                )"""

            if getattr(resp, "output_text", None):
                logger.debug(f'Assistant response (step {_step}): {resp.output_text}\n')
                final_text_chunks.append(resp.output_text)
            else:
                # fallback
                logger.debug(f'No output_text, instead printing output:\n\n {resp.output}\n\n\n')
                out = resp.output or []
                if out and hasattr(out[0], "content"):
                    c = out[0].content
                    if c and hasattr(c[0], "text"):
                        text = c[0].text
                    else:
                        text = None
                else:
                    text = None

            cont, new_id, new_args, last_call, results = await handle_tool_turn(resp, messages, session, last_call_id, last_call_args)
            if not cont:
                break

            last_call_id = new_id
            last_call_args = new_args
            final_text_chunks.append(f"[Tool {getattr(last_call, 'name', None)} returned: {results[0].text}]\n\nafter {_step + 1} loops.\n")


        return final_text_chunks[-1] if final_text_chunks else "No response from model."


def _parse_args():
    ap = argparse.ArgumentParser(description="MCP↔OpenAI CLI (weather tool demo)")
    ap.add_argument("--server", required=True, help="Path to MCP server entry (e.g., .\\weather.py)")
    ap.add_argument("--query", required=True, help="User query for the agent")
    ap.add_argument("--model", default=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"))
    return ap.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    print(asyncio.run(run(args.query, args.server, model=args.model)))
    """Get weather forecast for a location."""